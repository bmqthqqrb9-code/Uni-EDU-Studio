duet.walk(1)
