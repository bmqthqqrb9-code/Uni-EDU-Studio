duet.backward(1)
